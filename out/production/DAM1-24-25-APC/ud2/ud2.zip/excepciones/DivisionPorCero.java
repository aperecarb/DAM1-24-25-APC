package excepciones;

public class DivisionPorCero {
    public static void main(String[] args) {
        int a = 4, b = 0;
            
            System.out.println(a/b);
            System.out.println("División exitosa");

    }
        
}
