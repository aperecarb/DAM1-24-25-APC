package funciones;

public class E0401 {
    public static void main(String[] args) {
        eco(11);
    }

    static void eco(int n) {
        for (int i = 0; i < n; i++) {
            System.out.println("Eco...");
        }
    }
}
